Member: Nandini Ashok Bhole
Email: nandinibhole03@gmail.com
Week 1 Role: Data Quality Analyst

Primary datasets:
- ../../shared_data/regional_transactions.csv
- ../../shared_data/competitor_pricing.csv
- ../../shared_data/market_context.csv
- ../../shared_data/treatment_calendar.csv
- ../../shared_data/region_network.csv

5-day responsibility plan:
- Day 1: Check missing values, duplicate IDs/rows, invalid types, zero units, and invalid/missing prices.
- Day 2: Create an automated data-quality report with counts, percentages, and failed-rule summaries.
- Day 3: Validate the merged market dataset for row inflation, key duplication, missing joins, and inconsistent dates/regions.
- Day 4: Add reusable validation tests for required columns, positive values, valid keys, and uniqueness.
- Day 5: Finalize the Week 1 data-quality report and issue log.

Expected deliverables:
- src/validation.py
- tests/test_data_quality.py
- reports/data_quality_report.csv
- reports/data_quality_summary.md