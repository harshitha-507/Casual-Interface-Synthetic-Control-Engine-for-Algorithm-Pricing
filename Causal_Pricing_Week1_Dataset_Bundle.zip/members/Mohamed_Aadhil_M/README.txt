Member: Mohamed Aadhil M
Email: npmmdaadhil12@gmail.com
Week 1 Role: Causal Inference Analyst

Primary datasets:
- ../../shared_data/market_context.csv
- ../../shared_data/treatment_calendar.csv
- ../../shared_data/region_network.csv
- ../../shared_data/cleaned merged dataset produced by the team

5-day responsibility plan:
- Day 1: Define the causal question, treatment, outcome, candidate confounders, mediators, and interference risks.
- Day 2: Build the initial Directed Acyclic Graph using DoWhy/Graphviz-compatible notation.
- Day 3: Refine the DAG using EDA results and identify an adjustment set; distinguish confounders from mediators.
- Day 4: Initialize a DoWhy CausalModel and run identify_effect() on the cleaned analysis dataset.
- Day 5: Document DAG assumptions, adjustment variables, and limitations caused by network spillovers.

Expected deliverables:
- src/causal_graph.py
- outputs/dag/causal_dag.dot
- outputs/dag/causal_dag.png
- reports/causal_assumptions.md