Member: Sandeep Pal
Email: sandeeppal0440@gmail.com
Week 1 Role: Market Data Analyst

Primary datasets:
- ../../shared_data/competitor_pricing.csv
- ../../shared_data/regional_transactions.csv

5-day responsibility plan:
- Day 1: Ingest competitor pricing telemetry and standardize competitor/product/region/time fields.
- Day 2: Handle missing competitor prices, deduplicate telemetry, and aggregate competitor prices by date-region-product.
- Day 3: Merge competitor pricing aggregates with the transaction aggregate using common market keys.
- Day 4: Create competitor price gap, price ratio, relative price index, and competitor promotion features.
- Day 5: Document the competitor pricing pipeline and feature definitions.

Expected deliverables:
- src/competitor.py
- outputs/competitor_daily_agg.csv
- outputs/market_with_competitor_features.csv
- reports/competitor_pipeline_notes.md