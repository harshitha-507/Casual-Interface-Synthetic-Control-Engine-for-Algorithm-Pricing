Member: Bhumika
Email: bhumika.poojary15@gmail.com
Week 1 Role: Data Engineer

Primary datasets:
- ../../shared_data/regional_transactions.csv
- ../../shared_data/treatment_calendar.csv

5-day responsibility plan:
- Day 1: Ingest regional transaction data, inspect schema, standardize column names and data types.
- Day 2: Clean date/region/product fields, recalculate revenue where possible, and aggregate to date-region-product level.
- Day 3: Prepare the transaction dataset at the common merge grain for causal analysis.
- Day 4: Modularize the ingestion code into reusable load/clean/aggregate functions.
- Day 5: Document schema, source fields, aggregation logic, and final outputs.

Expected deliverables:
- src/ingestion.py
- outputs/transactions_daily_agg.csv
- reports/transaction_schema_summary.md