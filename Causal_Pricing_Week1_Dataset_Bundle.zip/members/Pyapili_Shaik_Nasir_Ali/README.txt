Member: Pyapili Shaik Nasir Ali
Email: nasirali0546@gmail.com
Week 1 Role: Time-Series / Synthetic Control Analyst

Primary datasets:
- ../../shared_data/treatment_calendar.csv
- ../../shared_data/market_context.csv
- ../../shared_data/region_network.csv
- ../../shared_data/cleaned merged dataset produced by the team

5-day responsibility plan:
- Day 1: Define pre-treatment, treatment, and control periods from the treatment calendar.
- Day 2: Split the cleaned dataset into pre-treatment/treatment/control-period subsets.
- Day 3: Build pre-treatment revenue and pricing trajectories by region.
- Day 4: Compare observed treatment-period performance with baseline descriptively and identify candidate donor regions.
- Day 5: Document baseline logic, control-region shortlist, and any network-exposed controls to avoid or flag.

Expected deliverables:
- src/treatment_split.py
- outputs/pre_treatment_baseline.csv
- outputs/control_region_shortlist.csv
- reports/baseline_analysis.md