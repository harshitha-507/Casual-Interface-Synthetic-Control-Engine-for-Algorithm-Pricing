Member: Harshitha Annamaneni
Email: annamaneniharshitha@gmail.com
Week 1 Role: Data Analyst

Primary datasets:
- ../../shared_data/regional_transactions.csv
- ../../shared_data/market_context.csv
- ../../shared_data/competitor_pricing.csv

5-day responsibility plan:
- Day 1: Perform initial EDA: dataset size, summary statistics, revenue/price distributions, region and product trends.
- Day 2: Engineer calendar, price-change, price-gap, revenue-per-order, and market-context features.
- Day 3: Perform causal-focused EDA for price vs revenue/demand and competitor price relationships.
- Day 4: Create presentation-ready market, revenue, price, and data-quality visualizations.
- Day 5: Summarize EDA findings and candidate features for downstream causal modeling.

Expected deliverables:
- notebooks/04_eda_features.ipynb
- outputs/engineered_features.csv
- outputs/figures/
- reports/eda_summary.md