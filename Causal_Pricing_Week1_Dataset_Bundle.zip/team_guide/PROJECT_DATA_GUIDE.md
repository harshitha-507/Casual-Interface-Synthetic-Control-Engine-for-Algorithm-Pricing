# Causal Inference & Synthetic Control Engine for Algorithmic Pricing
## Week 1 Dataset Guide

This is a **fully synthetic dataset** created for your 6-person project team.

### Shared files
| File | Rows | Main use |
|---|---:|---|
| regional_transactions.csv | 25,249 | Regional transaction ingestion, cleaning, revenue aggregation |
| competitor_pricing.csv | 23,348 | Competitor pricing telemetry and pricing features |
| market_context.csv | 1,944 | Demand, seasonality, marketing, weather, inventory and spillover context |
| treatment_calendar.csv | 8 | Treatment/control assignment and intervention dates |
| region_network.csv | 8 | Directed relationships between regions for spillover analysis |
| member_responsibilities.csv | 6 | Member ownership and expected outputs |

### Treatment design
- Treatment begins on **2026-07-01**.
- Treated regions: **R01 North Metro** and **R04 West Metro**.
- Other regions are control candidates.
- Some control regions have simulated **network exposure** from treated regions, so they may not be perfect controls.

### Important variables
- Treatment candidates: `pricing_treatment_flag`, `dynamic_price_multiplier`
- Primary outcome candidate: `revenue`
- Potential confounders: `demand_index`, `seasonality_index`, `promotion_flag`, `competitor_price`,
  `marketing_spend`, `inventory_level`, `weather_index`, `holiday_flag`, `weekend_flag`
- Interference/spillover: `network_exposure`, `spillover_weight`

### Intentional data-quality challenges
The raw files intentionally contain a small number of:
- duplicate transaction/quote rows
- missing selling prices
- zero-unit transactions
- missing region names
- missing competitor prices
- missing marketing-spend values

These issues are deliberate so the Data Quality Analyst can create realistic validation checks.

### Recommended Week 1 join grain
1. Validate transaction-level uniqueness first.
2. Aggregate transactions to `date + region_id + product_id`.
3. Aggregate competitor telemetry to `date + region_id + product_id`.
4. Join those two aggregates.
5. Join `market_context.csv` on `date + region_id`.
6. Join `treatment_calendar.csv` on `region_id`.
7. Use `region_network.csv` separately to assess spillover/control suitability.

### Team rule
All members should use the same files from `shared_data/`. Do not create separate inconsistent copies of the raw data.
Commit only code, lightweight derived outputs, documentation, and small samples to GitHub if repository-size limits are a concern.
